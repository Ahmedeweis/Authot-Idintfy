package com.example.authorWebsite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuthorWebsiteApplication {

	public static void main(String[] args) {
		SpringApplication.run(AuthorWebsiteApplication.class, args);
	}

}
