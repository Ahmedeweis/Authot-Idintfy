package com.example.authorWebsite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthorWebsiteApplicationTests {

	@Test
	void contextLoads() {
	}

}
